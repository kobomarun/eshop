
						<main class="col-md-9 col-sm-8">

							<h1>My Dashboard</h1>

							<section class="theme_box">

								<h4>Welcome, <?php echo $this->session->userdata('fname'); ?></h4>

								<p>From your My Account Dashboard you have the ability to view a snapshot of your recent account activity and update your account information. Select a link below to view or edit information.</p>

							</section><!--/ .theme_box -->

							<!-- - - - - - - - - - - - - - Contact information - - - - - - - - - - - - - - - - -->

							<section class="theme_box">

								<h4>My Cart</h4>

								<p>Product Name<br></p>


							</section><!--/ .theme_box -->

              <section class="theme_box">

								<h4>My Orders</h4>

                <p>Product Name<br></p>
                <p>Product Name<br></p>


							</section><!--/ .theme_box -->


						</main><!--/ [col]-->

					</div>
