<aside class="col-md-3 col-sm-4">

  <!-- - - - - - - - - - - - - - Information - - - - - - - - - - - - - - - - -->

  <section class="section_offset">

    <h3>My Account</h3>

    <ul class="theme_menu">

      <li class="active"><a href="#">Account Dashboard</a></li>
      <li><a href="#">Account Information</a></li>
      <li><a href="#">My Orders</a></li>
      <li><a href="<?php echo base_url(); ?>cart/view">My Cart</a></li>

    </ul>

  </section><!--/ .section_offset -->

  <!-- - - - - - - - - - - - - - End of information - - - - - - - - - - - - - - - - -->

  <!-- - - - - - - - - - - - - - Banner - - - - - - - - - - - - - - - - -->

  <div class="section_offset">

    <a href="#" class="banner">

      <img src="images/banner_img_10.png" alt="">

    </a>

  </div>

  
